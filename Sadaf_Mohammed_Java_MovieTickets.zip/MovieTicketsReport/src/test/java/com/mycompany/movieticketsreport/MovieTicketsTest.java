package com.mycompany.movieticketsreport;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

/**
 * Unit tests for Question 1 (Q.1.3).
 */
public class MovieTicketsTest {

    private final MovieTickets movieTickets = new MovieTickets();

    @Test
    public void CalculateTotalSales_ReturnsExpectedTotalSales() {
        int[] napoleonSales = {3000, 1500, 1700};

        int result = movieTickets.TotalMovieSales(napoleonSales);

        assertEquals(6200, result);
    }

    @Test
    public void TopMovieSales_ReturnsTopMovie() {
        String[] movies = {"Napoleon", "Oppenheimer"};
        int[] totalSales = {6200, 6300};

        String result = movieTickets.TopMovie(movies, totalSales);

        assertEquals("Oppenheimer", result);
    }
}
