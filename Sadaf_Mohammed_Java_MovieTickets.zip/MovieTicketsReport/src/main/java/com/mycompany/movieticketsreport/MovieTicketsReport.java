package com.mycompany.movieticketsreport;

/**
 * Question 1: prints the movie ticket sales report for January to March 2024.
 */
public class MovieTicketsReport {

    public static void main(String[] args) {
        // Single dimensional arrays for the movie names and the months
        String[] movies = {"Napoleon", "Oppenheimer"};
        String[] months = {"JAN", "FEB", "MAR"};

        // Two dimensional array: one row per movie, one column per month
        int[][] ticketSales = {
            {3000, 1500, 1700},
            {3500, 1200, 1600}
        };

        MovieTickets movieTickets = new MovieTickets();

        // Work out the total sales for each movie and keep them in an array
        int[] totalSales = new int[movies.length];
        for (int i = 0; i < movies.length; i++) {
            totalSales[i] = movieTickets.TotalMovieSales(ticketSales[i]);
        }

        System.out.println("MOVIE TICKET SALES REPORT - 2024");
        System.out.println();

        // Heading row
        System.out.printf("%-15s", "");
        for (String month : months) {
            System.out.printf("%-12s", month);
        }
        System.out.println();
        System.out.println("-".repeat(51));

        // One row per movie
        for (int i = 0; i < movies.length; i++) {
            System.out.printf("%-15s", movies[i]);
            for (int j = 0; j < months.length; j++) {
                System.out.printf("%-12d", ticketSales[i][j]);
            }
            System.out.println();
        }
        System.out.println();

        for (int i = 0; i < movies.length; i++) {
            System.out.println("Total movie ticket sales for " + movies[i] + " " + totalSales[i]);
        }
        System.out.println();

        System.out.println("Top performing movie: " + movieTickets.TopMovie(movies, totalSales));
    }
}
