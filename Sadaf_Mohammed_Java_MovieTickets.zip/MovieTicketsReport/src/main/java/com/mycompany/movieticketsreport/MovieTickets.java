package com.mycompany.movieticketsreport;

/**
 * Does the calculations for the movie ticket sales report.
 */
public class MovieTickets implements IMovieTickets {

    /**
     * Adds up the ticket sales for one movie across all the months.
     */
    @Override
    public int TotalMovieSales(int[] movieTicketSales) {
        int total = 0;
        for (int sale : movieTicketSales) {
            total += sale;
        }
        return total;
    }

    /**
     * Returns the movie with the highest total sales. If two movies are
     * tied, the first one in the array is returned.
     */
    @Override
    public String TopMovie(String[] movies, int[] totalSales) {
        int topIndex = 0;
        for (int i = 1; i < totalSales.length; i++) {
            if (totalSales[i] > totalSales[topIndex]) {
                topIndex = i;
            }
        }
        return movies[topIndex];
    }
}
