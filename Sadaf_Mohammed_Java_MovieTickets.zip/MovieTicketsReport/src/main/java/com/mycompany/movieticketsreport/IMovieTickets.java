package com.mycompany.movieticketsreport;

/**
 * Interface given in the question paper (Q.1.2).
 */
public interface IMovieTickets {

    int TotalMovieSales(int[] movieTicketSales);

    String TopMovie(String[] movies, int[] totalSales);
}
