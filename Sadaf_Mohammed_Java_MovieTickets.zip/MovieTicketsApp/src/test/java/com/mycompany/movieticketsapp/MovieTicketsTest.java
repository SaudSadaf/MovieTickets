package com.mycompany.movieticketsapp;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.Test;

/**
 * Unit tests for Question 2 (Q.2.9).
 */
public class MovieTicketsTest {

    private final MovieTickets movieTickets = new MovieTickets();

    @Test
    public void CalculateTotalTicketPrice_CalculatedSuccessfully() {
        // 3 tickets x R100 = R300, plus 14% VAT = R342
        double result = movieTickets.CalculateTotalTicketPrice(3, 100);

        assertEquals(342.0, result, 0.001);
    }

    @Test
    public void ValidateData_InvalidNumberOfTickets_ReturnsFalse() {
        MovieTicketData data = new MovieTicketData("Napoleon", 0, 100);

        assertFalse(movieTickets.ValidateData(data));
    }

    @Test
    public void ValidateData_InvalidTicketPrice_ReturnsFalse() {
        MovieTicketData data = new MovieTicketData("Oppenheimer", 2, -50);

        assertFalse(movieTickets.ValidateData(data));
    }

    @Test
    public void ValidateData_EmptyMovieName_ReturnsFalse() {
        MovieTicketData data = new MovieTicketData("", 2, 100);

        assertFalse(movieTickets.ValidateData(data));
    }

    @Test
    public void ValidateData_ValidData_ReturnsTrue() {
        MovieTicketData data = new MovieTicketData("Damsel", 2, 80);

        assertTrue(movieTickets.ValidateData(data));
    }
}
