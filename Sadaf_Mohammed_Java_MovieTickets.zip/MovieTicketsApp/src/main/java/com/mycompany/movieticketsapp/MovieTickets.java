package com.mycompany.movieticketsapp;

/**
 * Calculates the total ticket price (including VAT) and validates the data
 * captured on the form.
 */
public class MovieTickets implements IMovieTickets {

    public static final double VAT_RATE = 0.14;

    /**
     * Total price = number of tickets x ticket price, plus 14% VAT.
     * Rounded to two decimals so 3 x R100 gives exactly R342.0.
     */
    @Override
    public double CalculateTotalTicketPrice(int numberOfTickets, double ticketPrice) {
        double subtotal = numberOfTickets * ticketPrice;
        double total = subtotal + (subtotal * VAT_RATE);
        return Math.round(total * 100.0) / 100.0;
    }

    /**
     * Movie name cannot be empty, and the ticket price and number of tickets
     * must both be greater than zero.
     */
    @Override
    public boolean ValidateData(MovieTicketData movieTicketData) {
        return getValidationMessage(movieTicketData).isEmpty();
    }

    /**
     * Returns an empty string when the data is valid, otherwise a message
     * explaining the first rule that failed. The form shows this message.
     */
    public String getValidationMessage(MovieTicketData movieTicketData) {
        if (movieTicketData == null) {
            return "No movie ticket data was captured.";
        }
        if (movieTicketData.getMovieName() == null || movieTicketData.getMovieName().trim().isEmpty()) {
            return "Please select a movie.";
        }
        if (movieTicketData.getTicketPrice() <= 0) {
            return "The ticket price must be greater than zero.";
        }
        if (movieTicketData.getNumberOfTickets() <= 0) {
            return "The number of tickets must be greater than zero.";
        }
        return "";
    }
}
