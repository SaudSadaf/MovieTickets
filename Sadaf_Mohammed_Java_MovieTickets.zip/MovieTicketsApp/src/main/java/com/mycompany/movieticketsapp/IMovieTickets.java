package com.mycompany.movieticketsapp;

/**
 * Interface given in the question paper (Q.2.8).
 */
public interface IMovieTickets {

    double CalculateTotalTicketPrice(int numberOfTickets, double ticketPrice);

    boolean ValidateData(MovieTicketData movieTicketData);
}
